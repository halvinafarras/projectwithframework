<nav class="bg-white border-b border-gray-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex space-x-6">
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="font-semibold <?php echo e(request()->routeIs('dashboard') ? 'text-pink-400' : 'text-gray-700'); ?>">
                    Dashboard
                </a>

                <?php if(auth()->user()->role === 'admin'): ?>
                <a href="<?php echo e(route('categories.index')); ?>"
                    class="<?php echo e(request()->routeIs('categories.*') ? 'text-pink-400' : 'text-gray-500'); ?>">
                    Kategori
                </a>
                <a href="<?php echo e(route('products.index')); ?>"
                    class="<?php echo e(request()->routeIs('products.*') ? 'text-pink-400' : 'text-gray-500'); ?>">
                    Produk
                </a>
                <a href="<?php echo e(route('report.sales')); ?>"
                    class="<?php echo e(request()->routeIs('report.sales') ? 'text-pink-400' : 'text-gray-500'); ?>">
                    Laporan
                </a>
                <?php endif; ?>

                <a href="<?php echo e(route('pos.index')); ?>"
                    class="<?php echo e(request()->routeIs('pos.index') ? 'text-pink-400' : 'text-gray-500'); ?>">
                    Transaksi
                </a>

                <?php if(auth()->user()->role === 'kasir'): ?>
                <a href="<?php echo e(route('pos.history')); ?>"
                    class="<?php echo e(request()->routeIs('pos.history') ? 'text-pink-400' : 'text-gray-500'); ?>">
                    Riwayat Transaksi
                </a>
                <?php endif; ?>
            </div>

            <div class="flex items-center space-x-4 text-sm">
                <span class="text-gray-600"><?php echo e(auth()->user()->name); ?></span>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-gray-500 hover:text-red-600">Keluar</button>
                </form>
            </div>
        </div>
    </div>
</nav><?php /**PATH /Users/halvinafarrassavitri/Documents/Semester 5/Framework/Praktikum2/resources/views/layouts/navigation.blade.php ENDPATH**/ ?>