<div>
    <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

    <?php
    if ($status === 'Aman') {
    $class = 'bg-green-100 text-green-800';
    } elseif ($status === 'Menipis') {
    $class = 'bg-yellow-100 text-yellow-800';
    } else {
    $class = 'bg-red-100 text-red-800';
    }
    ?>

    <span class="px-2 py-1 text-sm rounded <?php echo e($class); ?>">
        <?php echo e($status); ?>

    </span>
</div><?php /**PATH /Users/halvinafarrassavitri/Documents/Semester 5/Framework/Praktikum2/resources/views/components/badge.blade.php ENDPATH**/ ?>