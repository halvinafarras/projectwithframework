<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckRole
{
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        if (! $request->user() || ! in_array($request->user()->role, $roles)) {
            // abort(403, 'Anda tidak memiliki akses ke halaman ini.');
            return response()->view('auth.custom-403', [], 403);
        }

        return $next($request);
    }
}
